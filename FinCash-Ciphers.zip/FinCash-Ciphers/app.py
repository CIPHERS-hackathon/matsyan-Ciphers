from flask import Flask, render_template, request, redirect, url_for, jsonify, session
import json
import os
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__, static_folder='static', template_folder='templates')
app.secret_key = 'your_secret_key_here'  # Change this for production

# Database file path
DB_FILE = 'database.json'

def init_db():
    if not os.path.exists(DB_FILE):
        with open(DB_FILE, 'w') as f:
            json.dump({"users": []}, f)
    else:
        try:
            with open(DB_FILE, 'r') as f:
                json.load(f)
        except (json.JSONDecodeError, FileNotFoundError):
            with open(DB_FILE, 'w') as f:
                json.dump({"users": []}, f)

def read_db():
    try:
        with open(DB_FILE, 'r') as f:
            data = json.load(f)
            if 'users' not in data:
                data = {'users': []}
            return data
    except (json.JSONDecodeError, FileNotFoundError):
        init_db()
        return {'users': []}

def write_db(data):
    with open(DB_FILE, 'w') as f:
        json.dump(data, f, indent=4)

def user_exists(email):
    db = read_db()
    return any(user['email'] == email for user in db['users'])

def add_user(name, email, phone, password):
    db = read_db()
    db['users'].append({
        'name': name,
        'email': email,
        'phone': phone,
        'password': generate_password_hash(password)
    })
    write_db(db)

def verify_user(email, password):
    db = read_db()
    user = next((user for user in db['users'] if user['email'] == email), None)
    if user and check_password_hash(user['password'], password):
        return user
    return None

@app.route('/')
def index():
    return render_template('login.html')

@app.route('/signup', methods=['POST'])
def signup():
    data = request.get_json()
    name = data.get('name')
    email = data.get('email')
    phone = data.get('phone')
    password = data.get('password')
    
    if not all([name, email, phone, password]):
        return jsonify({"success": False, "message": "All fields are required"}), 400
    
    if user_exists(email):
        return jsonify({"success": False, "message": "Email already registered"}), 400
    
    add_user(name, email, phone, password)
    return jsonify({"success": True, "message": "Account created successfully"})

@app.route('/signin', methods=['POST'])
def signin():
    data = request.get_json()
    email = data.get('email')
    password = data.get('password')
    
    if not all([email, password]):
        return jsonify({"success": False, "message": "Email and password are required"}), 400
    
    user = verify_user(email, password)
    if not user:
        return jsonify({"success": False, "message": "Invalid credentials"}), 401
    
    session['user'] = {
        'name': user['name'],
        'email': user['email'],
        'phone': user['phone']
    }
    return jsonify({"success": True, "message": "Login successful", "user": user['name']})

@app.route('/home')
def home():
    if 'user' not in session:
        return redirect(url_for('login'))
    return render_template('home.html', user=session['user'])

@app.route('/logout')
def logout():
    session.pop('user', None)
    return redirect(url_for('login'))

@app.route('/auction')
def auction():
    return render_template('auction.html')

@app.route('/globalchat')
def globalchat():
    return render_template('globalchat.html')

@app.route('/market')
def market():
    return render_template('market.html')


if __name__ == '__main__':
    init_db()
    app.run(debug=True, port=5000)