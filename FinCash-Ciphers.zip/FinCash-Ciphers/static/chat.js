document.addEventListener('DOMContentLoaded', function() {
    // Theme Toggle (same as other pages)
    const themeToggle = document.getElementById('theme-toggle');
    themeToggle.addEventListener('click', toggleTheme);
    
    // Profile Menu Toggle (same as other pages)
    const profileIcon = document.getElementById('profile-icon');
    const profileMenu = document.getElementById('profile-menu');
    profileIcon.addEventListener('click', (e) => {
        e.stopPropagation();
        profileMenu.classList.toggle('show');
    });
    
    // Close profile menu when clicking outside (same as other pages)
    document.addEventListener('click', () => {
        profileMenu.classList.remove('show');
    });
    
    // Chat functionality
    const chatContainer = document.getElementById('chat-container');
    const messageInput = document.getElementById('message-input');
    const sendButton = document.getElementById('send-button');
    const onlineCount = document.getElementById('online-count');
    
    // Simulate online users (in a real app, this would come from server)
    let usersOnline = Math.floor(Math.random() * 50) + 10;
    onlineCount.textContent = usersOnline;
    
    // Sample chat messages
    const sampleMessages = [
        {
            sender: "Fisherman123",
            time: new Date(Date.now() - 60000),
            content: "Has anyone caught any pomfret today?"
        },
        {
            sender: "SeafoodLover",
            time: new Date(Date.now() - 30000),
            content: "The market prices seem high this week"
        },
        {
            sender: "BoatMaster",
            time: new Date(Date.now() - 15000),
            content: "Going out to sea tomorrow, weather looks good"
        }
    ];
    
    // Load sample messages
    sampleMessages.forEach(msg => {
        addMessage(msg.sender, msg.content, msg.time, false);
    });
    
    // Send message function
    function sendMessage() {
        const message = messageInput.value.trim();
        if (message) {
            // In a real app, this would send to a server
            addMessage("You", message, new Date(), true);
            messageInput.value = "";
            
            // Simulate response (in a real app, this would come from server)
            setTimeout(() => {
                const responses = [
                    "Interesting point!",
                    "I agree with that",
                    "Prices are high today",
                    "Has anyone seen the new regulations?",
                    "Good weather for fishing tomorrow"
                ];
                const randomResponse = responses[Math.floor(Math.random() * responses.length)];
                addMessage("Fisherman" + Math.floor(Math.random() * 100), randomResponse, new Date(), false);
            }, 1000 + Math.random() * 3000);
        }
    }
    
    // Add message to chat
    function addMessage(sender, content, time, isOwn) {
        const messageElement = document.createElement('div');
        messageElement.className = `message ${isOwn ? 'own' : ''}`;
        
        const timeString = time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        
        messageElement.innerHTML = `
            <div class="message-header">
                <span class="message-sender">${sender}</span>
                <span class="message-time">${timeString}</span>
            </div>
            <div class="message-content">${content}</div>
        `;
        
        chatContainer.appendChild(messageElement);
        chatContainer.scrollTop = chatContainer.scrollHeight;
    }
    
    // Event listeners
    sendButton.addEventListener('click', sendMessage);
    
    messageInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            sendMessage();
        }
    });
    
    // Simulate users joining/leaving (in a real app, this would come from server)
    setInterval(() => {
        const change = Math.floor(Math.random() * 3) - 1; // -1, 0, or 1
        usersOnline = Math.max(5, usersOnline + change);
        onlineCount.textContent = usersOnline;
    }, 5000);
    
    // Theme toggle function (same as other pages)
    function toggleTheme() {
        document.body.classList.toggle('dark-theme');
        const icon = document.querySelector('#theme-toggle i');
        
        // Save theme preference
        const isDark = document.body.classList.contains('dark-theme');
        localStorage.setItem('darkTheme', isDark);
        
        if (isDark) {
            icon.classList.remove('fa-moon');
            icon.classList.add('fa-sun');
        } else {
            icon.classList.remove('fa-sun');
            icon.classList.add('fa-moon');
        }
    }
    
    // Check for saved theme preference (same as other pages)
    if (localStorage.getItem('darkTheme') === 'true') {
        document.body.classList.add('dark-theme');
        const icon = document.querySelector('#theme-toggle i');
        icon.classList.remove('fa-moon');
        icon.classList.add('fa-sun');
    }
});