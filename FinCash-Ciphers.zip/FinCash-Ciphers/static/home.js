// Theme Toggle
const themeToggle = document.getElementById('theme-toggle');
const themeIcon = themeToggle.querySelector('i');

// Check for saved theme preference
const savedTheme = localStorage.getItem('theme');
if (savedTheme) {
    document.body.classList.add(savedTheme);
    if (savedTheme === 'dark-theme') {
        themeIcon.classList.replace('fa-moon', 'fa-sun');
    }
}

themeToggle.addEventListener('click', () => {
    document.body.classList.toggle('dark-theme');
    
    // Save theme preference
    const currentTheme = document.body.classList.contains('dark-theme') ? 'dark-theme' : '';
    localStorage.setItem('theme', currentTheme);
    
    if (document.body.classList.contains('dark-theme')) {
        themeIcon.classList.replace('fa-moon', 'fa-sun');
    } else {
        themeIcon.classList.replace('fa-sun', 'fa-moon');
    }
});

// Profile Menu Toggle
const profileIcon = document.getElementById('profile-icon');
const profileMenu = document.getElementById('profile-menu');

profileIcon.addEventListener('click', (e) => {
    e.stopPropagation();
    profileMenu.classList.toggle('show');
});

// Close profile menu when clicking outside
document.addEventListener('click', (e) => {
    if (!e.target.closest('.user-profile')) {
        profileMenu.classList.remove('show');
    }
});

// Filter Toggle
const filterBtn = document.getElementById('filter-btn');
const filterOptions = document.getElementById('filter-options');

filterBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    filterOptions.classList.toggle('show');
});

// Close filter when clicking outside
document.addEventListener('click', (e) => {
    if (!e.target.closest('.filter-section')) {
        filterOptions.classList.remove('show');
    }
});

// Fish Data (from your JSON)
const fishData = [
    {
        "id": 1,
        "name": "Rohu",
        "pricePerKg": 250,
        "weightInKg": 1.2,
        "image": "images/rohu.jpg",
        "type": "freshwater"
    },
    {
        "id": 2,
        "name": "Katla",
        "pricePerKg": 280,
        "weightInKg": 1.5,
        "image": "images/katla.jpg",
        "type": "freshwater"
    },
    {
        "id": 3,
        "name": "Hilsa",
        "pricePerKg": 900,
        "weightInKg": 0.8,
        "image": "images/hilsa.jpg",
        "type": "saltwater"
    },
    {
        "id": 4,
        "name": "Pomfret",
        "pricePerKg": 750,
        "weightInKg": 1.0,
        "image": "images/pomfret.jpg",
        "type": "saltwater"
    },
    {
        "id": 5,
        "name": "Surmai (Kingfish)",
        "pricePerKg": 850,
        "weightInKg": 1.3,
        "image": "images/surmai.jpg",
        "type": "saltwater"
    },
    {
        "id": 6,
        "name": "Sardine",
        "pricePerKg": 180,
        "weightInKg": 0.5,
        "image": "images/sardine.jpg",
        "type": "saltwater"
    },
    {
        "id": 7,
        "name": "Mackerel (Bangda)",
        "pricePerKg": 220,
        "weightInKg": 0.7,
        "image": "images/mackerel.jpg",
        "type": "saltwater"
    },
    {
        "id": 8,
        "name": "Tilapia",
        "pricePerKg": 200,
        "weightInKg": 1.1,
        "image": "images/tilapia.jpg",
        "type": "freshwater"
    },
    {
        "id": 9,
        "name": "Seer Fish",
        "pricePerKg": 800,
        "weightInKg": 2.0,
        "image": "images/seer.jpg",
        "type": "saltwater"
    },
    {
        "id": 10,
        "name": "Prawn",
        "pricePerKg": 700,
        "weightInKg": 0.4,
        "image": "images/prawn.jpg",
        "type": "shellfish"
    },
    {
        "id": 11,
        "name": "Crab",
        "pricePerKg": 650,
        "weightInKg": 0.8,
        "image": "images/crab.jpg",
        "type": "shellfish"
    },
    {
        "id": 12,
        "name": "Snapper",
        "pricePerKg": 550,
        "weightInKg": 1.2,
        "image": "images/snapper.jpg",
        "type": "saltwater"
    },
    {
        "id": 13,
        "name": "Grouper",
        "pricePerKg": 600,
        "weightInKg": 1.5,
        "image": "images/grouper.jpg",
        "type": "saltwater"
    },
    {
        "id": 14,
        "name": "Barramundi",
        "pricePerKg": 500,
        "weightInKg": 1.4,
        "image": "images/barramundi.jpg",
        "type": "saltwater"
    },
    {
        "id": 15,
        "name": "Trout",
        "pricePerKg": 450,
        "weightInKg": 0.9,
        "image": "images/trout.jpg",
        "type": "freshwater"
    },
    {
        "id": 16,
        "name": "Carp",
        "pricePerKg": 300,
        "weightInKg": 2.2,
        "image": "images/carp.jpg",
        "type": "freshwater"
    },
    {
        "id": 17,
        "name": "Catfish",
        "pricePerKg": 350,
        "weightInKg": 1.7,
        "image": "images/catfish.jpg",
        "type": "freshwater"
    },
    {
        "id": 18,
        "name": "Anchovy",
        "pricePerKg": 160,
        "weightInKg": 0.3,
        "image": "images/anchovy.jpg",
        "type": "saltwater"
    },
    {
        "id": 19,
        "name": "Clownfish",
        "pricePerKg": 1200,
        "weightInKg": 0.2,
        "image": "images/clownfish.jpg",
        "type": "saltwater"
    },
    {
        "id": 20,
        "name": "Tuna",
        "pricePerKg": 750,
        "weightInKg": 2.5,
        "image": "images/tuna.jpg",
        "type": "saltwater"
    },
    {
        "id": 21,
        "name": "Salmon",
        "pricePerKg": 900,
        "weightInKg": 3.0,
        "image": "images/salmon.jpg",
        "type": "saltwater"
    },
    {
        "id": 22,
        "name": "Cod",
        "pricePerKg": 400,
        "weightInKg": 1.8,
        "image": "images/cod.jpg",
        "type": "saltwater"
    },
    {
        "id": 23,
        "name": "Haddock",
        "pricePerKg": 380,
        "weightInKg": 1.7,
        "image": "images/haddock.jpg",
        "type": "saltwater"
    },
    {
        "id": 24,
        "name": "Sole",
        "pricePerKg": 450,
        "weightInKg": 0.6,
        "image": "images/sole.jpg",
        "type": "saltwater"
    },
    {
        "id": 25,
        "name": "Tilapia Wild",
        "pricePerKg": 220,
        "weightInKg": 1.2,
        "image": "images/tilapia_wild.jpg",
        "type": "freshwater"
    },
    {
        "id": 26,
        "name": "Snapper Red",
        "pricePerKg": 580,
        "weightInKg": 1.3,
        "image": "images/snapper_red.jpg",
        "type": "saltwater"
    },
    {
        "id": 27,
        "name": "Mahi Mahi",
        "pricePerKg": 650,
        "weightInKg": 1.6,
        "image": "images/mahi.jpg",
        "type": "saltwater"
    },
    {
        "id": 28,
        "name": "Swordfish",
        "pricePerKg": 950,
        "weightInKg": 2.3,
        "image": "images/swordfish.jpg",
        "type": "saltwater"
    },
    {
        "id": 29,
        "name": "Marlin",
        "pricePerKg": 1000,
        "weightInKg": 3.5,
        "image": "images/marlin.jpg",
        "type": "saltwater"
    },
    {
        "id": 30,
        "name": "Barracuda",
        "pricePerKg": 550,
        "weightInKg": 1.5,
        "image": "images/barracuda.jpg",
        "type": "saltwater"
    },
    {
        "id": 31,
        "name": "Snapper Pink",
        "pricePerKg": 600,
        "weightInKg": 1.4,
        "image": "images/snapper_pink.jpg",
        "type": "saltwater"
    },
    {
        "id": 32,
        "name": "Yellowtail",
        "pricePerKg": 700,
        "weightInKg": 1.8,
        "image": "images/yellowtail.jpg",
        "type": "saltwater"
    },
    {
        "id": 33,
        "name": "Flounder",
        "pricePerKg": 420,
        "weightInKg": 0.7,
        "image": "images/flounder.jpg",
        "type": "saltwater"
    },
    {
        "id": 34,
        "name": "Tiger Fish",
        "pricePerKg": 650,
        "weightInKg": 1.2,
        "image": "images/tigerfish.jpg",
        "type": "freshwater"
    },
    {
        "id": 35,
        "name": "Tilapia Farmed",
        "pricePerKg": 180,
        "weightInKg": 1.0,
        "image": "images/tilapia_farmed.jpg",
        "type": "freshwater"
    },
    {
        "id": 36,
        "name": "Freshwater Prawn",
        "pricePerKg": 720,
        "weightInKg": 0.5,
        "image": "images/fw_prawn.jpg",
        "type": "shellfish"
    },
    {
        "id": 37,
        "name": "Marine Prawn",
        "pricePerKg": 750,
        "weightInKg": 0.4,
        "image": "images/fw_prawn.jpg",
        "type": "shellfish"
    },
    {
        "id": 38,
        "name": "Lobster",
        "pricePerKg": 1200,
        "weightInKg": 1.0,
        "image": "images/lobster.jpg",
        "type": "shellfish"
    },
    {
        "id": 39,
        "name": "Scallop",
        "pricePerKg": 1400,
        "weightInKg": 0.3,
        "image": "images/scallop.jpg",
        "type": "shellfish"
    },
    {
        "id": 40,
        "name": "Oyster",
        "pricePerKg": 1100,
        "weightInKg": 0.6,
        "image": "images/oyster.jpg",
        "type": "shellfish"
    },
    {
        "id": 41,
        "name": "Clam",
        "pricePerKg": 300,
        "weightInKg": 0.4,
        "image": "images/clam.jpg",
        "type": "shellfish"
    },
    {
        "id": 42,
        "name": "Mussels",
        "pricePerKg": 280,
        "weightInKg": 0.5,
        "image": "images/mussels.jpg",
        "type": "shellfish"
    },
    {
        "id": 43,
        "name": "Octopus",
        "pricePerKg": 900,
        "weightInKg": 1.2,
        "image": "images/octopus.jpg",
        "type": "shellfish"
    },
    {
        "id": 44,
        "name": "Cuttlefish",
        "pricePerKg": 650,
        "weightInKg": 1.0,
        "image": "images/cuttlefish.jpg",
        "type": "shellfish"
    },
    {
        "id": 45,
        "name": "Squid",
        "pricePerKg": 700,
        "weightInKg": 0.8,
        "image": "images/squid.jpg",
        "type": "shellfish"
    },
    {
        "id": 46,
        "name": "Langoustine",
        "pricePerKg": 1300,
        "weightInKg": 0.4,
        "image": "images/langoustine.jpg",
        "type": "shellfish"
    },
    {
        "id": 47,
        "name": "Sea Bass",
        "pricePerKg": 650,
        "weightInKg": 1.3,
        "image": "images/seabass.jpg",
        "type": "saltwater"
    },
    {
        "id": 48,
        "name": "Snapper Gold",
        "pricePerKg": 600,
        "weightInKg": 1.1,
        "image": "images/snapper_gold.jpg",
        "type": "saltwater"
    },
    {
        "id": 49,
        "name": "Pollock",
        "pricePerKg": 320,
        "weightInKg": 1.5,
        "image": "images/pollock.jpg",
        "type": "saltwater"
    },
    {
        "id": 50,
        "name": "Whitebait",
        "pricePerKg": 200,
        "weightInKg": 0.2,
        "image": "images/whitebait.jpg",
        "type": "saltwater"
    },
    {
        "id": 51,
        "name": "Butterfish",
        "pricePerKg": 480,
        "weightInKg": 0.6,
        "image": "images/butterfish.jpg",
        "type": "saltwater"
    },
    {
        "id": 52,
        "name": "John Dory",
        "pricePerKg": 850,
        "weightInKg": 1.0,
        "image": "images/johndory.jpg",
        "type": "saltwater"
    },
    {
        "id": 53,
        "name": "Tilefish",
        "pricePerKg": 700,
        "weightInKg": 1.2,
        "image": "images/tilefish.jpg",
        "type": "saltwater"
    },
    {
        "id": 54,
        "name": "Monkfish",
        "pricePerKg": 760,
        "weightInKg": 1.4,
        "image": "images/monkfish.jpg",
        "type": "saltwater"
    },
    {
        "id": 55,
        "name": "Anchovy Small",
        "pricePerKg": 150,
        "weightInKg": 0.25,
        "image": "images/anchovy_small.jpg",
        "type": "saltwater"
    },
    {
        "id": 56,
        "name": "Sea Trout",
        "pricePerKg": 500,
        "weightInKg": 1.2,
        "image": "images/seatrout.jpg",
        "type": "saltwater"
    }
];

// Display Fish Cards
const fishGrid = document.getElementById('fish-grid');

function displayFish(fishArray) {
    fishGrid.innerHTML = '';
    
    fishArray.forEach(fish => {
        const totalPrice = (fish.pricePerKg * fish.weightInKg).toFixed(2);
        
        const fishCard = document.createElement('div');
        fishCard.className = 'fish-card';
        fishCard.innerHTML = `
            <div class="fish-details">
                <h3 class="fish-name">${fish.name}</h3>
                <div class="fish-info">
                    <span>Weight: ${fish.weightInKg}kg</span>
                    <span class="fish-price">₹${totalPrice}</span>
                </div>
                <div class="quantity-controls">
                    <button class="quantity-btn minus">-</button>
                    <span class="quantity-display">1</span>
                    <button class="quantity-btn plus">+</button>
                </div>
                <button class="buy-btn">Buy Now</button>
            </div>
        `;
        
        fishGrid.appendChild(fishCard);
        
        // Add event listeners for quantity buttons
        const minusBtn = fishCard.querySelector('.minus');
        const plusBtn = fishCard.querySelector('.plus');
        const quantityDisplay = fishCard.querySelector('.quantity-display');
        
        let quantity = 1;
        
        minusBtn.addEventListener('click', () => {
            if (quantity > 1) {
                quantity--;
                quantityDisplay.textContent = quantity;
            }
        });
        
        plusBtn.addEventListener('click', () => {
            quantity++;
            quantityDisplay.textContent = quantity;
        });
    });
}

// Initial display
displayFish(fishData);

// Filter functionality
const typeFilter = document.getElementById('type-filter');
const priceFilter = document.getElementById('price-filter');
const weightFilter = document.getElementById('weight-filter');

function applyFilters() {
    const typeValue = typeFilter.value;
    const priceValue = priceFilter.value;
    const weightValue = weightFilter.value;
    
    let filteredFish = [...fishData];
    
    // Type filter - now properly checks the type property
    if (typeValue !== 'all') {
        filteredFish = filteredFish.filter(fish => {
            if (!fish.type) {
                // Fallback for fish without type property
                if (typeValue === 'freshwater') {
                    return freshwaterFish.includes(fish.name.split(' ')[0]);
                } else if (typeValue === 'saltwater') {
                    return saltwaterFish.includes(fish.name.split(' ')[0]);
                } else if (typeValue === 'shellfish') {
                    return shellfish.includes(fish.name.split(' ')[0]);
                }
                return true;
            }
            return fish.type === typeValue;
        });
    }
    
    // Price filter (unchanged - works fine)
    if (priceValue !== 'all') {
        const [min, max] = priceValue.includes('+') ? 
            [parseInt(priceValue.replace('+', '')), Infinity] : 
            priceValue.split('-').map(Number);
        
        filteredFish = filteredFish.filter(fish => {
            const price = fish.pricePerKg * fish.weightInKg;
            return price >= min && (max === Infinity || price <= max);
        });
    }
    
    // Weight filter (unchanged - works fine)
    if (weightValue !== 'all') {
        const [min, max] = weightValue.includes('+') ? 
            [parseFloat(weightValue.replace('+', '')), Infinity] : 
            weightValue.split('-').map(Number);
        
        filteredFish = filteredFish.filter(fish => {
            return fish.weightInKg >= min && (max === Infinity || fish.weightInKg <= max);
        });
    }
    
    displayFish(filteredFish);
}

// Add event listeners to filters
typeFilter.addEventListener('change', applyFilters);
priceFilter.addEventListener('change', applyFilters);
weightFilter.addEventListener('change', applyFilters);