document.addEventListener('DOMContentLoaded', function() {
    // Theme Toggle
    const themeToggle = document.getElementById('theme-toggle');
    if (themeToggle) themeToggle.addEventListener('click', toggleTheme);
    
    // Profile Menu Toggle
    const profileIcon = document.getElementById('profile-icon');
    const profileMenu = document.getElementById('profile-menu');
    if (profileIcon && profileMenu) {
        profileIcon.addEventListener('click', (e) => {
            e.stopPropagation();
            profileMenu.classList.toggle('show');
        });
    }
    
    // Close profile menu when clicking outside
    document.addEventListener('click', () => {
        if (profileMenu) profileMenu.classList.remove('show');
    });
    
    // Load auctions
    loadAuctions();
    
    // Create Auction Modal
    const startAuctionBtn = document.getElementById('start-auction-btn');
    const createAuctionModal = document.getElementById('create-auction-modal');
    const closeCreateModal = document.getElementById('close-create-modal');
    
    if (startAuctionBtn && createAuctionModal) {
        startAuctionBtn.addEventListener('click', () => {
            createAuctionModal.style.display = 'flex';
        });
    }
    
    if (closeCreateModal && createAuctionModal) {
        closeCreateModal.addEventListener('click', () => {
            createAuctionModal.style.display = 'none';
        });
    }
    
    // Auction Form Submission
    const auctionForm = document.getElementById('auction-form');
    if (auctionForm) {
        auctionForm.addEventListener('submit', (e) => {
            e.preventDefault();
            
            const fishType = document.getElementById('fish-type').value;
            const fishWeight = document.getElementById('fish-weight').value;
            const basePrice = document.getElementById('base-price').value;
            const duration = document.getElementById('auction-duration').value;
            
            // Create new auction
            const newAuction = {
                id: Date.now(),
                fishType,
                weight: fishWeight,
                basePrice: parseInt(basePrice),
                currentBid: parseInt(basePrice),
                duration: parseInt(duration) * 60,
                endTime: new Date(Date.now() + parseInt(duration) * 60000).toISOString(),
                bids: [],
                status: 'active'
            };
            
            // Add to auctions array
            let auctions = [];
            try {
                auctions = JSON.parse(localStorage.getItem('auctions')) || sampleAuctions;
            } catch (e) {
                auctions = sampleAuctions;
            }
            auctions.push(newAuction);
            
            try {
                localStorage.setItem('auctions', JSON.stringify(auctions));
            } catch (e) {
                console.error("LocalStorage not available:", e);
            }
            
            // Reload auctions
            loadAuctions();
            
            // Close modal and reset form
            if (createAuctionModal) createAuctionModal.style.display = 'none';
            auctionForm.reset();
        });
    }
    
    // Your Auctions Button
    const yourAuctionsBtn = document.getElementById('your-auctions-btn');
    if (yourAuctionsBtn) {
        yourAuctionsBtn.addEventListener('click', () => {
            alert('Your auctions feature coming soon!');
        });
    }
});

function toggleTheme() {
    document.body.classList.toggle('dark-theme');
    const icon = document.querySelector('#theme-toggle i');
    if (!icon) return;
    
    // Save theme preference
    const isDark = document.body.classList.contains('dark-theme');
    try {
        localStorage.setItem('darkTheme', isDark);
    } catch (e) {
        console.error("Couldn't save theme preference:", e);
    }
    
    if (isDark) {
        icon.classList.remove('fa-moon');
        icon.classList.add('fa-sun');
    } else {
        icon.classList.remove('fa-sun');
        icon.classList.add('fa-moon');
    }
}

// Check for saved theme preference
try {
    if (localStorage.getItem('darkTheme') === 'true') {
        document.body.classList.add('dark-theme');
        const icon = document.querySelector('#theme-toggle i');
        if (icon) {
            icon.classList.remove('fa-moon');
            icon.classList.add('fa-sun');
        }
    }
} catch (e) {
    console.error("Couldn't load theme preference:", e);
}

function loadAuctions() {
    const auctionList = document.getElementById('auction-list');
    if (!auctionList) return;
    
    auctionList.innerHTML = '';
    
    // Load from localStorage or use sample data if empty
    let auctions = [];
    try {
        auctions = JSON.parse(localStorage.getItem('auctions')) || sampleAuctions;
    } catch (e) {
        auctions = sampleAuctions;
    }
    
    // Update auction statuses based on time
    const now = new Date();
    auctions = auctions.map(auction => {
        const endTime = new Date(auction.endTime);
        if (endTime < now && auction.status === 'active') {
            auction.status = 'completed';
        }
        return auction;
    });
    
    // Save updated auctions
    try {
        localStorage.setItem('auctions', JSON.stringify(auctions));
    } catch (e) {
        console.error("Couldn't save auctions:", e);
    }
    
    // Filter active auctions
    const activeAuctions = auctions.filter(auction => auction.status === 'active');
    
    if (activeAuctions.length === 0) {
        auctionList.innerHTML = '<p class="no-auctions" style="grid-column:1/-1;text-align:center;padding:40px;color:var(--muted-text)">No active auctions at the moment.</p>';
        return;
    }
    
    activeAuctions.forEach(auction => {
        const auctionCard = document.createElement('div');
        auctionCard.className = 'auction-card';
        auctionCard.innerHTML = `
            <div class="auction-details">
                <h3 class="auction-title">${auction.fishType}</h3>
                <div class="auction-meta">
                    <span>${auction.weight} kg</span>
                    <div class="auction-timer">
                        <i class="fas fa-clock"></i> ${formatTimeRemaining(auction.endTime)}
                    </div>
                </div>
                <div class="auction-price">₹${auction.currentBid}</div>
                <button class="view-btn">View Auction</button>
            </div>
        `;
        
        auctionCard.addEventListener('click', (e) => {
            if (!e.target.classList.contains('view-btn')) return;
            showAuctionDetail(auction);
        });
        
        auctionList.appendChild(auctionCard);
    });
}

function showAuctionDetail(auction) {
    const detailModal = document.getElementById('auction-detail-modal');
    const closeDetailModal = document.getElementById('close-detail-modal');
    if (!detailModal || !closeDetailModal) return;
    
    // Set auction details
    document.getElementById('detail-fish-type').textContent = auction.fishType;
    document.getElementById('detail-weight').textContent = `${auction.weight} kg`;
    document.getElementById('detail-base-price').textContent = `₹${auction.basePrice}`;
    document.getElementById('detail-current-bid').textContent = `₹${auction.currentBid}`;
    
    // Update timer display
    const timerElement = document.getElementById('time-remaining');
    const updateTimer = () => {
        const now = new Date();
        const endTime = new Date(auction.endTime);
        const diff = Math.max(0, endTime - now);
        
        const minutes = Math.floor(diff / 60000);
        const seconds = Math.floor((diff % 60000) / 1000);
        if (timerElement) {
            timerElement.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
        }
        
        if (diff <= 0) {
            clearInterval(timerInterval);
            if (timerElement) timerElement.textContent = 'Auction Ended';
            const bidBtn = document.getElementById('place-bid-btn');
            if (bidBtn) bidBtn.disabled = true;
        }
    };
    
    updateTimer();
    const timerInterval = setInterval(updateTimer, 1000);
    
    // Load bid history
    const bidsList = document.getElementById('bids-list');
    if (bidsList) {
        bidsList.innerHTML = '';
        
        if (auction.bids.length === 0) {
            bidsList.innerHTML = '<p style="text-align:center;color:var(--muted-text)">No bids yet</p>';
        } else {
            auction.bids.forEach(bid => {
                const bidItem = document.createElement('div');
                bidItem.className = 'bid-item';
                bidItem.innerHTML = `
                    <span class="bid-amount">₹${bid.amount}</span>
                    <span class="bid-time">${new Date(bid.time).toLocaleTimeString()}</span>
                `;
                bidsList.appendChild(bidItem);
            });
        }
    }
    
    // Bid button functionality
    const placeBidBtn = document.getElementById('place-bid-btn');
    const bidAmountInput = document.getElementById('bid-amount');
    
    if (placeBidBtn && bidAmountInput) {
        placeBidBtn.addEventListener('click', () => {
            const bidAmount = parseInt(bidAmountInput.value);
            
            if (isNaN(bidAmount)) {
                alert('Please enter a valid bid amount');
                return;
            }
            
            if (bidAmount <= auction.currentBid) {
                alert(`Your bid must be higher than the current bid of ₹${auction.currentBid}`);
                return;
            }
            
            // Add new bid
            const newBid = {
                amount: bidAmount,
                time: new Date().toISOString(),
                bidder: 'You'
            };
            
            auction.bids.push(newBid);
            auction.currentBid = bidAmount;
            
            // Update in localStorage
            let auctions = [];
            try {
                auctions = JSON.parse(localStorage.getItem('auctions')) || [];
            } catch (e) {
                console.error("Couldn't load auctions:", e);
            }
            auctions = auctions.map(a => a.id === auction.id ? auction : a);
            
            try {
                localStorage.setItem('auctions', JSON.stringify(auctions));
            } catch (e) {
                console.error("Couldn't save auctions:", e);
            }
            
            // Update UI
            const currentBidElement = document.getElementById('detail-current-bid');
            if (currentBidElement) {
                currentBidElement.textContent = `₹${auction.currentBid}`;
            }
            
            if (bidsList) {
                const bidItem = document.createElement('div');
                bidItem.className = 'bid-item';
                bidItem.innerHTML = `
                    <span class="bid-amount">₹${newBid.amount}</span>
                    <span class="bid-time">${new Date(newBid.time).toLocaleTimeString()}</span>
                `;
                bidsList.prepend(bidItem);
            }
            
            bidAmountInput.value = '';
        });
    }
    
    // Show modal
    detailModal.style.display = 'flex';
    
    // Close modal
    closeDetailModal.addEventListener('click', () => {
        detailModal.style.display = 'none';
        clearInterval(timerInterval);
    });
    
    // Close modal when clicking outside
    detailModal.addEventListener('click', (e) => {
        if (e.target === detailModal) {
            detailModal.style.display = 'none';
            clearInterval(timerInterval);
        }
    });
}

function formatTimeRemaining(endTime) {
    const now = new Date();
    const end = new Date(endTime);
    const diff = Math.max(0, end - now);
    
    const minutes = Math.floor(diff / 60000);
    const seconds = Math.floor((diff % 60000) / 1000);
    
    return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
}

// Sample auction data
const sampleAuctions = [
    {
        id: 1,
        fishType: 'Pomfret',
        weight: 2.5,
        basePrice: 300,
        currentBid: 450,
        duration: 1800,
        endTime: new Date(Date.now() + 30 * 60000).toISOString(),
        bids: [
            { amount: 350, time: new Date(Date.now() - 5 * 60000).toISOString(), bidder: 'User1' },
            { amount: 400, time: new Date(Date.now() - 3 * 60000).toISOString(), bidder: 'User2' },
            { amount: 450, time: new Date(Date.now() - 1 * 60000).toISOString(), bidder: 'User3' }
        ],
        status: 'active'
    },
    {
        id: 2,
        fishType: 'Seer Fish',
        weight: 3.2,
        basePrice: 500,
        currentBid: 750,
        duration: 3600,
        endTime: new Date(Date.now() + 60 * 60000).toISOString(),
        bids: [
            { amount: 550, time: new Date(Date.now() - 15 * 60000).toISOString(), bidder: 'User4' },
            { amount: 600, time: new Date(Date.now() - 10 * 60000).toISOString(), bidder: 'User5' },
            { amount: 750, time: new Date(Date.now() - 5 * 60000).toISOString(), bidder: 'User6' }
        ],
        status: 'active'
    },
    {
        id: 3,
        fishType: 'King Fish',
        weight: 4.0,
        basePrice: 700,
        currentBid: 900,
        duration: 2700,
        endTime: new Date(Date.now() + 45 * 60000).toISOString(),
        bids: [
            { amount: 750, time: new Date(Date.now() - 20 * 60000).toISOString(), bidder: 'User7' },
            { amount: 800, time: new Date(Date.now() - 15 * 60000).toISOString(), bidder: 'User8' },
            { amount: 900, time: new Date(Date.now() - 5 * 60000).toISOString(), bidder: 'User9' }
        ],
        status: 'active'
    }
];