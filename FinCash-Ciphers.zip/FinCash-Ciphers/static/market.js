document.addEventListener('DOMContentLoaded', function() {
    // Theme Toggle (same as other pages)
    const themeToggle = document.getElementById('theme-toggle');
    themeToggle.addEventListener('click', toggleTheme);
    
    // Profile Menu Toggle (same as other pages)
    const profileIcon = document.getElementById('profile-icon');
    const profileMenu = document.getElementById('profile-menu');
    profileIcon.addEventListener('click', (e) => {
        e.stopPropagation();
        profileMenu.classList.toggle('show');
    });
    
    // Close profile menu when clicking outside (same as other pages)
    document.addEventListener('click', () => {
        profileMenu.classList.remove('show');
    });
    
    // Load market data
    loadMarketData();
    
    // Initialize charts
    initCharts();
    
    // Set up filter event listeners
    document.querySelector('.apply-filters').addEventListener('click', applyFilters);
    
    // Set up chart period buttons
    document.querySelectorAll('.chart-period').forEach(btn => {
        btn.addEventListener('click', function() {
            document.querySelectorAll('.chart-period').forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            updateCharts(this.dataset.period);
        });
    });
});

function toggleTheme() {
    document.body.classList.toggle('dark-theme');
    const icon = document.querySelector('#theme-toggle i');
    
    // Save theme preference
    const isDark = document.body.classList.contains('dark-theme');
    localStorage.setItem('darkTheme', isDark);
    
    if (isDark) {
        icon.classList.remove('fa-moon');
        icon.classList.add('fa-sun');
    } else {
        icon.classList.remove('fa-sun');
        icon.classList.add('fa-moon');
    }
}

// Check for saved theme preference
if (localStorage.getItem('darkTheme') === 'true') {
    document.body.classList.add('dark-theme');
    const icon = document.querySelector('#theme-toggle i');
    icon.classList.remove('fa-moon');
    icon.classList.add('fa-sun');
}

// Market data
let marketData = {};

// Load market data from JSON
async function loadMarketData() {
    try {
        const response = await fetch('market-data.json');
        marketData = await response.json();
        populateMarketOverview();
        populateForecasts();
        populateRecommendations();
    } catch (error) {
        console.error('Error loading market data:', error);
        // Fallback to sample data if JSON fails to load
        marketData = sampleMarketData;
        populateMarketOverview();
        populateForecasts();
        populateRecommendations();
    }
}

// Populate Market Overview section
function populateMarketOverview() {
    const priceIndicators = document.getElementById('price-indicators');
    const supplyDemand = document.getElementById('supply-demand');
    const marketStatus = document.getElementById('market-status');
    
    // Clear existing content
    priceIndicators.innerHTML = '';
    supplyDemand.innerHTML = '';
    marketStatus.innerHTML = '';
    
    // Add price indicators
    marketData.currentPrices.forEach(item => {
        const priceElement = document.createElement('div');
        priceElement.className = 'price-indicator';
        
        const changeClass = item.change >= 0 ? 'up' : 'down';
        const changeSymbol = item.change >= 0 ? '▲' : '▼';
        
        priceElement.innerHTML = `
            <span class="fish-name">${item.fish}</span>
            <div>
                <span class="price-value">₹${item.price.toFixed(2)}</span>
                <span class="price-change ${changeClass}">${changeSymbol} ${Math.abs(item.change)}%</span>
            </div>
        `;
        priceIndicators.appendChild(priceElement);
    });
    
    // Add supply-demand metrics
    const supplyElement = document.createElement('div');
    supplyElement.className = 'metric-item';
    supplyElement.innerHTML = `
        <span>Total Daily Catch:</span>
        <strong>${marketData.supplyDemand.totalCatch} tons</strong>
    `;
    supplyDemand.appendChild(supplyElement);
    
    const demandElement = document.createElement('div');
    demandElement.className = 'metric-item';
    demandElement.innerHTML = `
        <span>Demand Level:</span>
        <strong class="demand-${marketData.supplyDemand.demandLevel.toLowerCase()}">
            ${marketData.supplyDemand.demandLevel}
        </strong>
    `;
    supplyDemand.appendChild(demandElement);
    
    const inventoryElement = document.createElement('div');
    inventoryElement.className = 'metric-item';
    inventoryElement.innerHTML = `
        <span>Inventory Level:</span>
        <strong>${marketData.supplyDemand.inventoryLevel}</strong>
    `;
    supplyDemand.appendChild(inventoryElement);
    
    // Add market status
    const statusElement = document.createElement('div');
    statusElement.className = `status ${marketData.marketStatus.trend.toLowerCase()}`;
    statusElement.innerHTML = `
        <h4>${marketData.marketStatus.status}</h4>
        <p>${marketData.marketStatus.description}</p>
    `;
    marketStatus.appendChild(statusElement);
}

// Initialize charts
function initCharts() {
    // Price Trend Chart
    const priceTrendCtx = document.getElementById('price-trend-chart').getContext('2d');
    window.priceTrendChart = new Chart(priceTrendCtx, {
        type: 'line',
        data: {
            labels: marketData.priceTrends.dates.slice(-7),
            datasets: marketData.priceTrends.varieties.map(variety => ({
                label: variety.name,
                data: variety.prices.slice(-7),
                borderColor: variety.color,
                backgroundColor: 'rgba(0, 74, 173, 0.1)',
                borderWidth: 2,
                tension: 0.1,
                fill: true
            }))
        },
        options: getChartOptions('Price Trends (₹/kg)')
    });
    
    // Regional Heatmap
    const heatmapCtx = document.getElementById('regional-heatmap').getContext('2d');
    window.regionalHeatmap = new Chart(heatmapCtx, {
        type: 'bar',
        data: {
            labels: marketData.regionalPrices.regions,
            datasets: [{
                label: 'Average Price (₹)',
                data: marketData.regionalPrices.prices,
                backgroundColor: marketData.regionalPrices.prices.map(price => {
                    const maxPrice = Math.max(...marketData.regionalPrices.prices);
                    const ratio = price / maxPrice;
                    return `rgba(0, 74, 173, ${0.3 + ratio * 0.7})`;
                }),
                borderColor: marketData.regionalPrices.prices.map(price => {
                    const maxPrice = Math.max(...marketData.regionalPrices.prices);
                    const ratio = price / maxPrice;
                    return `rgba(0, 74, 173, ${0.5 + ratio * 0.5})`;
                }),
                borderWidth: 1
            }]
        },
        options: getChartOptions('Regional Price Variations')
    });
    
    // Forecast Chart
    const forecastCtx = document.getElementById('forecast-chart').getContext('2d');
    window.forecastChart = new Chart(forecastCtx, {
        type: 'line',
        data: {
            labels: marketData.forecast.dates,
            datasets: [{
                label: 'Price Forecast',
                data: marketData.forecast.prices,
                borderColor: '#004aad',
                backgroundColor: 'rgba(0, 74, 173, 0.1)',
                borderWidth: 2,
                tension: 0.1,
                fill: true
            }]
        },
        options: getChartOptions('Price Forecast (Next 30 Days)')
    });
    
    // YoY Comparison Chart
    const yoyCtx = document.getElementById('yoy-chart').getContext('2d');
    window.yoyChart = new Chart(yoyCtx, {
        type: 'bar',
        data: {
            labels: ['Current', 'Last Year', '5-Year Avg'],
            datasets: [{
                label: 'Pomfret',
                data: [
                    marketData.comparison.current.pomfret,
                    marketData.comparison.lastYear.pomfret,
                    marketData.comparison.fiveYearAvg.pomfret
                ],
                backgroundColor: 'rgba(0, 74, 173, 0.7)'
            }, {
                label: 'Seer Fish',
                data: [
                    marketData.comparison.current.seer,
                    marketData.comparison.lastYear.seer,
                    marketData.comparison.fiveYearAvg.seer
                ],
                backgroundColor: 'rgba(46, 204, 113, 0.7)'
            }, {
                label: 'King Fish',
                data: [
                    marketData.comparison.current.king,
                    marketData.comparison.lastYear.king,
                    marketData.comparison.fiveYearAvg.king
                ],
                backgroundColor: 'rgba(241, 196, 15, 0.7)'
            }]
        },
        options: getChartOptions('Year-over-Year Comparison')
    });
}

function getChartOptions(title) {
    return {
        responsive: true,
        plugins: {
            legend: {
                position: 'top',
                labels: {
                    color: getComputedStyle(document.body).getPropertyValue('--text-color')
                }
            },
            title: {
                display: true,
                text: title,
                color: getComputedStyle(document.body).getPropertyValue('--text-color'),
                font: {
                    size: 16
                }
            },
            tooltip: {
                mode: 'index',
                intersect: false,
                backgroundColor: getComputedStyle(document.body).getPropertyValue('--modal-bg'),
                titleColor: getComputedStyle(document.body).getPropertyValue('--text-color'),
                bodyColor: getComputedStyle(document.body).getPropertyValue('--text-color'),
                borderColor: getComputedStyle(document.body).getPropertyValue('--divider-color'),
                borderWidth: 1
            }
        },
        scales: {
            x: {
                grid: {
                    color: getComputedStyle(document.body).getPropertyValue('--divider-color')
                },
                ticks: {
                    color: getComputedStyle(document.body).getPropertyValue('--text-color')
                }
            },
            y: {
                grid: {
                    color: getComputedStyle(document.body).getPropertyValue('--divider-color')
                },
                ticks: {
                    color: getComputedStyle(document.body).getPropertyValue('--text-color')
                },
                beginAtZero: false
            }
        },
        interaction: {
            mode: 'nearest',
            axis: 'x',
            intersect: false
        }
    };
}

// Update charts based on selected period
function updateCharts(period) {
    const days = parseInt(period);
    if (isNaN(days)) return;
    
    // Update price trend chart
    window.priceTrendChart.data.labels = marketData.priceTrends.dates.slice(-days);
    window.priceTrendChart.data.datasets.forEach(dataset => {
        dataset.data = dataset.data.slice(-days);
    });
    window.priceTrendChart.update();
}

// Apply filters
function applyFilters() {
    const fishType = document.getElementById('fish-type-filter').value;
    const timePeriod = document.getElementById('time-period').value;
    const region = document.getElementById('region-filter').value;
    
    // In a real app, this would filter the data from the server
    console.log('Filters applied:', { fishType, timePeriod, region });
    
    // For demo purposes, we'll just show a message
    alert(`Filters applied:\nFish Type: ${fishType}\nTime Period: ${timePeriod}\nRegion: ${region}`);
}

// Populate forecast sections
function populateForecasts() {
    const shortTerm = document.getElementById('short-term-forecast');
    const longTerm = document.getElementById('long-term-forecast');
    
    shortTerm.innerHTML = '';
    longTerm.innerHTML = '';
    
    // Short-term forecasts
    marketData.shortTermForecast.forEach(item => {
        const element = document.createElement('div');
        element.className = 'forecast-item';
        element.innerHTML = `
            <span class="forecast-label">${item.label}</span>
            <span class="forecast-value ${item.trend}">${item.value}</span>
        `;
        shortTerm.appendChild(element);
    });
    
    // Long-term forecasts
    marketData.longTermForecast.forEach(item => {
        const element = document.createElement('div');
        element.className = 'forecast-item';
        element.innerHTML = `
            <span class="forecast-label">${item.label}</span>
            <span class="forecast-value ${item.trend}">${item.value}</span>
        `;
        longTerm.appendChild(element);
    });
}

// Populate recommendations
function populateRecommendations() {
    const recommendations = document.getElementById('buy-sell-recommendations');
    const alerts = document.getElementById('inventory-alerts');
    
    recommendations.innerHTML = '';
    alerts.innerHTML = '';
    
    // Buy/Sell recommendations
    marketData.recommendations.buySell.forEach(item => {
        const element = document.createElement('div');
        element.className = 'recommendation-item';
        element.innerHTML = `
            <i class="fas fa-${item.icon}"></i>
            <div class="recommendation-content">
                <strong>${item.title}</strong>
                <p>${item.description}</p>
            </div>
        `;
        recommendations.appendChild(element);
    });
    
    // Inventory alerts
    marketData.recommendations.inventory.forEach(item => {
        const element = document.createElement('div');
        element.className = `alert-item ${item.type}`;
        element.innerHTML = `
            <i class="fas fa-${item.icon}"></i>
            <div class="alert-content">
                <strong>${item.title}</strong>
                <p>${item.description}</p>
            </div>
        `;
        alerts.appendChild(element);
    });
    
    // Competitor benchmarking table
    const benchmarkTable = document.getElementById('competitor-benchmarking');
    benchmarkTable.innerHTML = `
        <table class="benchmark-table">
            <thead>
                <tr>
                    <th>Fish Type</th>
                    <th>FinCash Price</th>
                    <th>Market Price</th>
                    <th>Difference</th>
                </tr>
            </thead>
            <tbody>
                ${marketData.competitorBenchmarking.map(item => `
                    <tr>
                        <td>${item.fish}</td>
                        <td>₹${item.ourPrice.toFixed(2)}</td>
                        <td>₹${item.marketPrice.toFixed(2)}</td>
                        <td class="${item.difference >= 0 ? 'up' : 'down'}">
                            ${item.difference >= 0 ? '+' : ''}${item.difference.toFixed(2)}%
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
}

// Sample data structure (in case JSON fails to load)
const sampleMarketData = {
    currentPrices: [
        { fish: "Pomfret", price: 450.50, change: 2.3 },
        { fish: "Seer Fish", price: 750.25, change: -1.2 },
        { fish: "King Fish", price: 900.75, change: 3.7 },
        { fish: "Tuna", price: 600.00, change: 0.5 },
        { fish: "Sardines", price: 150.30, change: -2.8 }
    ],
    supplyDemand: {
        totalCatch: 1250,
        demandLevel: "High",
        inventoryLevel: "Moderate"
    },
    marketStatus: {
        status: "Upward Trend",
        trend: "upward",
        description: "Prices are generally increasing across most varieties"
    },
    priceTrends: {
        dates: Array.from({ length: 90 }, (_, i) => {
            const date = new Date();
            date.setDate(date.getDate() - 90 + i);
            return date.toLocaleDateString();
        }),
        varieties: [
            {
                name: "Pomfret",
                prices: Array.from({ length: 90 }, () => 400 + Math.random() * 100),
                color: "#004aad"
            },
            {
                name: "Seer Fish",
                prices: Array.from({ length: 90 }, () => 600 + Math.random() * 150),
                color: "#2ecc71"
            },
            {
                name: "King Fish",
                prices: Array.from({ length: 90 }, () => 700 + Math.random() * 200),
                color: "#f39c12"
            }
        ]
    },
    regionalPrices: {
        regions: ["Northern Coast", "Southern Coast", "Eastern Coast", "Western Coast"],
        prices: [480, 520, 460, 490]
    },
    forecast: {
        dates: Array.from({ length: 30 }, (_, i) => {
            const date = new Date();
            date.setDate(date.getDate() + i);
            return date.toLocaleDateString();
        }),
        prices: Array.from({ length: 30 }, (_, i) => 450 + Math.sin(i / 5) * 50 + i * 2)
    },
    shortTermForecast: [
        { label: "Next 3 days", value: "Prices expected to rise 2-3%", trend: "up" },
        { label: "Weather impact", value: "Favorable fishing conditions", trend: "stable" },
        { label: "Demand forecast", value: "Increasing demand expected", trend: "up" }
    ],
    longTermForecast: [
        { label: "Next month", value: "Seasonal increase expected", trend: "up" },
        { label: "Quarterly trend", value: "Steady growth projected", trend: "up" },
        { label: "Holiday impact", value: "High demand expected", trend: "up" }
    ],
    comparison: {
        current: { pomfret: 450, seer: 750, king: 900 },
        lastYear: { pomfret: 420, seer: 700, king: 850 },
        fiveYearAvg: { pomfret: 430, seer: 720, king: 880 }
    },
    competitorBenchmarking: [
        { fish: "Pomfret", ourPrice: 450.50, marketPrice: 460.25, difference: -2.1 },
        { fish: "Seer Fish", ourPrice: 750.25, marketPrice: 780.50, difference: -3.9 },
        { fish: "King Fish", ourPrice: 900.75, marketPrice: 890.25, difference: 1.2 },
        { fish: "Tuna", ourPrice: 600.00, marketPrice: 620.75, difference: -3.3 },
        { fish: "Sardines", ourPrice: 150.30, marketPrice: 145.50, difference: 3.3 }
    ],
    recommendations: {
        buySell: [
            {
                icon: "shopping-cart",
                title: "Best time to buy Pomfret",
                description: "Prices expected to rise next week"
            },
            {
                icon: "money-bill-wave",
                title: "Optimal selling window for King Fish",
                description: "Current prices 5% above monthly average"
            }
        ],
        inventory: [
            {
                icon: "exclamation-triangle",
                title: "Low inventory alert",
                description: "Seer Fish stocks below recommended levels",
                type: "warning"
            },
            {
                icon: "check-circle",
                title: "Good inventory levels",
                description: "Pomfret stocks at optimal levels",
                type: "success"
            }
        ]
    }
};