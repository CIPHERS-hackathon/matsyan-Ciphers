document.addEventListener('DOMContentLoaded', function() {
    // Theme Toggle
    const themeToggle = document.getElementById('theme-toggle');
    themeToggle.addEventListener('click', toggleTheme);
    
    // Profile Menu Toggle
    const profileIcon = document.getElementById('profile-icon');
    const profileMenu = document.getElementById('profile-menu');
    profileIcon.addEventListener('click', (e) => {
        e.stopPropagation();
        profileMenu.classList.toggle('show');
    });
    
    // Close profile menu when clicking outside
    document.addEventListener('click', () => {
        profileMenu.classList.remove('show');
    });
    
    // Market data (embedded directly in the JS file)
    const marketData = {
        "currentPrices": [
            { "fish": "Pomfret", "price": 450.50, "change": 2.3 },
            { "fish": "Seer Fish", "price": 750.25, "change": -1.2 },
            { "fish": "King Fish", "price": 900.75, "change": 3.7 },
            { "fish": "Tuna", "price": 600.00, "change": 0.5 },
            { "fish": "Sardines", "price": 150.30, "change": -2.8 }
        ],
        "supplyDemand": {
            "totalCatch": 1250,
            "demandLevel": "High",
            "inventoryLevel": "Moderate"
        },
        "marketStatus": {
            "status": "Upward Trend",
            "trend": "upward",
            "description": "Prices are generally increasing across most varieties"
        },
       "priceTrends": {
        "dates": [
            "2023-01-01", "2023-01-02", "2023-01-03", "2023-01-04", "2023-01-05",
            "2023-01-06", "2023-01-07", "2023-01-08", "2023-01-09", "2023-01-10",
            "2023-01-11", "2023-01-12", "2023-01-13", "2023-01-14", "2023-01-15",
            "2023-01-16", "2023-01-17", "2023-01-18", "2023-01-19", "2023-01-20",
            "2023-01-21", "2023-01-22", "2023-01-23", "2023-01-24", "2023-01-25",
            "2023-01-26", "2023-01-27", "2023-01-28", "2023-01-29", "2023-01-30",
            "2023-01-31", "2023-02-01", "2023-02-02", "2023-02-03", "2023-02-04",
            "2023-02-05", "2023-02-06", "2023-02-07", "2023-02-08", "2023-02-09",
            "2023-02-10", "2023-02-11", "2023-02-12", "2023-02-13", "2023-02-14",
            "2023-02-15", "2023-02-16", "2023-02-17", "2023-02-18", "2023-02-19",
            "2023-02-20", "2023-02-21", "2023-02-22", "2023-02-23", "2023-02-24",
            "2023-02-25", "2023-02-26", "2023-02-27", "2023-02-28", "2023-03-01",
            "2023-03-02", "2023-03-03", "2023-03-04", "2023-03-05", "2023-03-06",
            "2023-03-07", "2023-03-08", "2023-03-09", "2023-03-10", "2023-03-11",
            "2023-03-12", "2023-03-13", "2023-03-14", "2023-03-15", "2023-03-16",
            "2023-03-17", "2023-03-18", "2023-03-19", "2023-03-20", "2023-03-21",
            "2023-03-22", "2023-03-23", "2023-03-24", "2023-03-25", "2023-03-26",
            "2023-03-27", "2023-03-28", "2023-03-29", "2023-03-30", "2023-03-31"
        ],
            "varieties": [
            {
                "name": "Pomfret",
                "prices": [
                    420.50, 422.30, 421.75, 423.60, 425.25, 427.80, 430.15, 432.40,
                    435.20, 437.60, 440.25, 442.80, 445.30, 447.75, 450.20, 452.60,
                    455.00, 457.30, 459.75, 462.20, 460.50, 458.75, 457.20, 455.60,
                    454.00, 452.40, 450.80, 449.20, 447.60, 446.00, 444.40, 442.80,
                    441.20, 439.60, 438.00, 436.40, 434.80, 433.20, 431.60, 430.00,
                    428.40, 426.80, 425.20, 423.60, 422.00, 420.40, 418.80, 417.20,
                    415.60, 414.00, 412.40, 410.80, 409.20, 407.60, 406.00, 404.40,
                    402.80, 401.20, 399.60, 398.00, 396.40, 394.80, 393.20, 391.60,
                    390.00, 388.40, 386.80, 385.20, 383.60, 382.00, 380.40, 378.80,
                    377.20, 375.60, 374.00, 372.40, 370.80, 369.20, 367.60, 366.00,
                    364.40, 362.80, 361.20, 359.60, 358.00, 356.40, 354.80, 353.20,
                    351.60, 350.00
                ],
                    "color": "#004aad"
                },
                // ... (rest of the varieties)
                 {
                "name": "Seer Fish",
                "prices": [
                    720.25, 722.50, 725.75, 728.90, 732.15, 735.40, 738.65, 741.90,
                    745.15, 748.40, 751.65, 754.90, 758.15, 761.40, 764.65, 767.90,
                    771.15, 774.40, 777.65, 780.90, 778.25, 775.60, 773.00, 770.40,
                    767.80, 765.20, 762.60, 760.00, 757.40, 754.80, 752.20, 749.60,
                    747.00, 744.40, 741.80, 739.20, 736.60, 734.00, 731.40, 728.80,
                    726.20, 723.60, 721.00, 718.40, 715.80, 713.20, 710.60, 708.00,
                    705.40, 702.80, 700.20, 697.60, 695.00, 692.40, 689.80, 687.20,
                    684.60, 682.00, 679.40, 676.80, 674.20, 671.60, 669.00, 666.40,
                    663.80, 661.20, 658.60, 656.00, 653.40, 650.80, 648.20, 645.60,
                    643.00, 640.40, 637.80, 635.20, 632.60, 630.00, 627.40, 624.80,
                    622.20, 619.60, 617.00, 614.40, 611.80, 609.20, 606.60, 604.00,
                    601.40, 598.80
                ],
                "color": "#2ecc71"
            },
            {
                "name": "King Fish",
                "prices": [
                    850.75, 853.25, 855.75, 858.25, 860.75, 863.25, 865.75, 868.25,
                    870.75, 873.25, 875.75, 878.25, 880.75, 883.25, 885.75, 888.25,
                    890.75, 893.25, 895.75, 898.25, 895.50, 892.75, 890.00, 887.25,
                    884.50, 881.75, 879.00, 876.25, 873.50, 870.75, 868.00, 865.25,
                    862.50, 859.75, 857.00, 854.25, 851.50, 848.75, 846.00, 843.25,
                    840.50, 837.75, 835.00, 832.25, 829.50, 826.75, 824.00, 821.25,
                    818.50, 815.75, 813.00, 810.25, 807.50, 804.75, 802.00, 799.25,
                    796.50, 793.75, 791.00, 788.25, 785.50, 782.75, 780.00, 777.25,
                    774.50, 771.75, 769.00, 766.25, 763.50, 760.75, 758.00, 755.25,
                    752.50, 749.75, 747.00, 744.25, 741.50, 738.75, 736.00, 733.25,
                    730.50, 727.75, 725.00, 722.25, 719.50, 716.75, 714.00, 711.25,
                    708.50, 705.75
                ],
                "color": "#f39c12"
            }
            ]
        },
        "regionalPrices": {
            "regions": ["Northern Coast", "Southern Coast", "Eastern Coast", "Western Coast"],
            "prices": [480, 520, 460, 490]
        },
        "forecast": {
        "dates": [
            "2023-04-01", "2023-04-02", "2023-04-03", "2023-04-04", "2023-04-05",
            "2023-04-06", "2023-04-07", "2023-04-08", "2023-04-09", "2023-04-10",
            "2023-04-11", "2023-04-12", "2023-04-13", "2023-04-14", "2023-04-15",
            "2023-04-16", "2023-04-17", "2023-04-18", "2023-04-19", "2023-04-20",
            "2023-04-21", "2023-04-22", "2023-04-23", "2023-04-24", "2023-04-25",
            "2023-04-26", "2023-04-27", "2023-04-28", "2023-04-29", "2023-04-30"
        ],
            "prices": [
            450, 452, 455, 458, 462, 465, 468, 470, 473, 475,
            478, 480, 483, 485, 488, 490, 493, 495, 498, 500,
            503, 505, 508, 510, 513, 515, 518, 520, 523, 525
        ]
        },
        "shortTermForecast": [
            { "label": "Next 3 days", "value": "Prices expected to rise 2-3%", "trend": "up" },
            { "label": "Weather impact", "value": "Favorable fishing conditions", "trend": "stable" },
            { "label": "Demand forecast", "value": "Increasing demand expected", "trend": "up" }
        ],
        "longTermForecast": [
            { "label": "Next month", "value": "Seasonal increase expected", "trend": "up" },
            { "label": "Quarterly trend", "value": "Steady growth projected", "trend": "up" },
            { "label": "Holiday impact", "value": "High demand expected", "trend": "up" }
        ],
        "comparison": {
            "current": { "pomfret": 450, "seer": 750, "king": 900 },
            "lastYear": { "pomfret": 420, "seer": 700, "king": 850 },
            "fiveYearAvg": { "pomfret": 430, "seer": 720, "king": 880 }
        },
        "competitorBenchmarking": [
            { "fish": "Pomfret", "ourPrice": 450.50, "marketPrice": 460.25, "difference": -2.1 },
            { "fish": "Seer Fish", "ourPrice": 750.25, "marketPrice": 780.50, "difference": -3.9 },
            { "fish": "King Fish", "ourPrice": 900.75, "marketPrice": 890.25, "difference": 1.2 },
            { "fish": "Tuna", "ourPrice": 600.00, "marketPrice": 620.75, "difference": -3.3 },
            { "fish": "Sardines", "ourPrice": 150.30, "marketPrice": 145.50, "difference": 3.3 }
        ],
        "recommendations": {
            "buySell": [
                {
                    "icon": "shopping-cart",
                    "title": "Best time to buy Pomfret",
                    "description": "Prices expected to rise next week"
                },
                {
                    "icon": "money-bill-wave",
                    "title": "Optimal selling window for King Fish",
                    "description": "Current prices 5% above monthly average"
                }
            ],
            "inventory": [
                {
                    "icon": "exclamation-triangle",
                    "title": "Low inventory alert",
                    "description": "Seer Fish stocks below recommended levels",
                    "type": "warning"
                },
                {
                    "icon": "check-circle",
                    "title": "Good inventory levels",
                    "description": "Pomfret stocks at optimal levels",
                    "type": "success"
                }
            ]
        },
        "historicalData": {
             "pomfret": {
            "2008": { "min": 380, "max": 420, "avg": 400 },
            "2009": { "min": 390, "max": 430, "avg": 410 },
            "2010": { "min": 400, "max": 440, "avg": 420 },
            "2011": { "min": 410, "max": 450, "avg": 430 },
            "2012": { "min": 420, "max": 460, "avg": 440 },
            "2013": { "min": 430, "max": 470, "avg": 450 },
            "2014": { "min": 440, "max": 480, "avg": 460 },
            "2015": { "min": 450, "max": 490, "avg": 470 },
            "2016": { "min": 460, "max": 500, "avg": 480 },
            "2017": { "min": 470, "max": 510, "avg": 490 },
            "2018": { "min": 480, "max": 520, "avg": 500 },
            "2019": { "min": 490, "max": 530, "avg": 510 },
            "2020": { "min": 500, "max": 540, "avg": 520 },
            "2021": { "min": 510, "max": 550, "avg": 530 },
            "2022": { "min": 520, "max": 560, "avg": 540 },
            "2023": { "min": 530, "max": 570, "avg": 550 }
        
            },
            // ... (rest of fish historical data)
        }
    };

    // Load market data
    populateMarketOverview();
    populateForecasts();
    populateRecommendations();
    
    // Initialize charts
    initCharts();
    
    // Set up filter event listeners
    document.querySelector('.apply-filters').addEventListener('click', applyFilters);
    
    // Set up chart period buttons
    document.querySelectorAll('.chart-period').forEach(btn => {
        btn.addEventListener('click', function() {
            document.querySelectorAll('.chart-period').forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            updateCharts(this.dataset.period);
        });
    });

    function toggleTheme() {
        document.body.classList.toggle('dark-theme');
        const icon = document.querySelector('#theme-toggle i');
        
        const isDark = document.body.classList.contains('dark-theme');
        localStorage.setItem('darkTheme', isDark);
        
        if (isDark) {
            icon.classList.remove('fa-moon');
            icon.classList.add('fa-sun');
        } else {
            icon.classList.remove('fa-sun');
            icon.classList.add('fa-moon');
        }
    }

    // Check for saved theme preference
    if (localStorage.getItem('darkTheme') === 'true') {
        document.body.classList.add('dark-theme');
        const icon = document.querySelector('#theme-toggle i');
        icon.classList.remove('fa-moon');
        icon.classList.add('fa-sun');
    }
    // Market data
    

// Load market data from JSON
async function loadMarketData() {
    try {
        const response = await fetch('market-data.json');
        marketData = await response.json();
        populateMarketOverview();
        populateForecasts();
        populateRecommendations();
    } catch (error) {
        console.error('Error loading market data:', error);
        // Fallback to sample data if JSON fails to load
        marketData = sampleMarketData;
        populateMarketOverview();
        populateForecasts();
        populateRecommendations();
    }
}

// Populate Market Overview section
function populateMarketOverview() {
    const priceIndicators = document.getElementById('price-indicators');
    const supplyDemand = document.getElementById('supply-demand');
    const marketStatus = document.getElementById('market-status');
    
    // Clear existing content
    priceIndicators.innerHTML = '';
    supplyDemand.innerHTML = '';
    marketStatus.innerHTML = '';
    
    // Add price indicators
    marketData.currentPrices.forEach(item => {
        const priceElement = document.createElement('div');
        priceElement.className = 'price-indicator';
        
        const changeClass = item.change >= 0 ? 'up' : 'down';
        const changeSymbol = item.change >= 0 ? '▲' : '▼';
        
        priceElement.innerHTML = `
            <span class="fish-name">${item.fish}</span>
            <div>
                <span class="price-value">₹${item.price.toFixed(2)}</span>
                <span class="price-change ${changeClass}">${changeSymbol} ${Math.abs(item.change)}%</span>
            </div>
        `;
        priceIndicators.appendChild(priceElement);
    });
    
    // Add supply-demand metrics
    const supplyElement = document.createElement('div');
    supplyElement.className = 'metric-item';
    supplyElement.innerHTML = `
        <span>Total Daily Catch:</span>
        <strong>${marketData.supplyDemand.totalCatch} tons</strong>
    `;
    supplyDemand.appendChild(supplyElement);
    
    const demandElement = document.createElement('div');
    demandElement.className = 'metric-item';
    demandElement.innerHTML = `
        <span>Demand Level:</span>
        <strong class="demand-${marketData.supplyDemand.demandLevel.toLowerCase()}">
            ${marketData.supplyDemand.demandLevel}
        </strong>
    `;
    supplyDemand.appendChild(demandElement);
    
    const inventoryElement = document.createElement('div');
    inventoryElement.className = 'metric-item';
    inventoryElement.innerHTML = `
        <span>Inventory Level:</span>
        <strong>${marketData.supplyDemand.inventoryLevel}</strong>
    `;
    supplyDemand.appendChild(inventoryElement);
    
    // Add market status
    const statusElement = document.createElement('div');
    statusElement.className = `status ${marketData.marketStatus.trend.toLowerCase()}`;
    statusElement.innerHTML = `
        <h4>${marketData.marketStatus.status}</h4>
        <p>${marketData.marketStatus.description}</p>
    `;
    marketStatus.appendChild(statusElement);
}

// Initialize charts
function initCharts() {
    // Price Trend Chart
    const priceTrendCtx = document.getElementById('price-trend-chart').getContext('2d');
    window.priceTrendChart = new Chart(priceTrendCtx, {
        type: 'line',
        data: {
            labels: marketData.priceTrends.dates.slice(-7),
            datasets: marketData.priceTrends.varieties.map(variety => ({
                label: variety.name,
                data: variety.prices.slice(-7),
                borderColor: variety.color,
                backgroundColor: 'rgba(0, 74, 173, 0.1)',
                borderWidth: 2,
                tension: 0.1,
                fill: true
            }))
        },
        options: getChartOptions('Price Trends (₹/kg)')
    });
    
    // Regional Heatmap
    const heatmapCtx = document.getElementById('regional-heatmap').getContext('2d');
    window.regionalHeatmap = new Chart(heatmapCtx, {
        type: 'bar',
        data: {
            labels: marketData.regionalPrices.regions,
            datasets: [{
                label: 'Average Price (₹)',
                data: marketData.regionalPrices.prices,
                backgroundColor: marketData.regionalPrices.prices.map(price => {
                    const maxPrice = Math.max(...marketData.regionalPrices.prices);
                    const ratio = price / maxPrice;
                    return `rgba(0, 74, 173, ${0.3 + ratio * 0.7})`;
                }),
                borderColor: marketData.regionalPrices.prices.map(price => {
                    const maxPrice = Math.max(...marketData.regionalPrices.prices);
                    const ratio = price / maxPrice;
                    return `rgba(0, 74, 173, ${0.5 + ratio * 0.5})`;
                }),
                borderWidth: 1
            }]
        },
        options: getChartOptions('Regional Price Variations')
    });
    
    // Forecast Chart
    const forecastCtx = document.getElementById('forecast-chart').getContext('2d');
    window.forecastChart = new Chart(forecastCtx, {
        type: 'line',
        data: {
            labels: marketData.forecast.dates,
            datasets: [{
                label: 'Price Forecast',
                data: marketData.forecast.prices,
                borderColor: '#004aad',
                backgroundColor: 'rgba(0, 74, 173, 0.1)',
                borderWidth: 2,
                tension: 0.1,
                fill: true
            }]
        },
        options: getChartOptions('Price Forecast (Next 30 Days)')
    });
    
    // YoY Comparison Chart
    const yoyCtx = document.getElementById('yoy-chart').getContext('2d');
    window.yoyChart = new Chart(yoyCtx, {
        type: 'bar',
        data: {
            labels: ['Current', 'Last Year', '5-Year Avg'],
            datasets: [{
                label: 'Pomfret',
                data: [
                    marketData.comparison.current.pomfret,
                    marketData.comparison.lastYear.pomfret,
                    marketData.comparison.fiveYearAvg.pomfret
                ],
                backgroundColor: 'rgba(0, 74, 173, 0.7)'
            }, {
                label: 'Seer Fish',
                data: [
                    marketData.comparison.current.seer,
                    marketData.comparison.lastYear.seer,
                    marketData.comparison.fiveYearAvg.seer
                ],
                backgroundColor: 'rgba(46, 204, 113, 0.7)'
            }, {
                label: 'King Fish',
                data: [
                    marketData.comparison.current.king,
                    marketData.comparison.lastYear.king,
                    marketData.comparison.fiveYearAvg.king
                ],
                backgroundColor: 'rgba(241, 196, 15, 0.7)'
            }]
        },
        options: getChartOptions('Year-over-Year Comparison')
    });
}

function getChartOptions(title) {
    return {
        responsive: true,
        plugins: {
            legend: {
                position: 'top',
                labels: {
                    color: getComputedStyle(document.body).getPropertyValue('--text-color')
                }
            },
            title: {
                display: true,
                text: title,
                color: getComputedStyle(document.body).getPropertyValue('--text-color'),
                font: {
                    size: 16
                }
            },
            tooltip: {
                mode: 'index',
                intersect: false,
                backgroundColor: getComputedStyle(document.body).getPropertyValue('--modal-bg'),
                titleColor: getComputedStyle(document.body).getPropertyValue('--text-color'),
                bodyColor: getComputedStyle(document.body).getPropertyValue('--text-color'),
                borderColor: getComputedStyle(document.body).getPropertyValue('--divider-color'),
                borderWidth: 1
            }
        },
        scales: {
            x: {
                grid: {
                    color: getComputedStyle(document.body).getPropertyValue('--divider-color')
                },
                ticks: {
                    color: getComputedStyle(document.body).getPropertyValue('--text-color')
                }
            },
            y: {
                grid: {
                    color: getComputedStyle(document.body).getPropertyValue('--divider-color')
                },
                ticks: {
                    color: getComputedStyle(document.body).getPropertyValue('--text-color')
                },
                beginAtZero: false
            }
        },
        interaction: {
            mode: 'nearest',
            axis: 'x',
            intersect: false
        }
    };
}

// Update charts based on selected period
function updateCharts(period) {
    const days = parseInt(period);
    if (isNaN(days)) return;
    
    // Update price trend chart
    window.priceTrendChart.data.labels = marketData.priceTrends.dates.slice(-days);
    window.priceTrendChart.data.datasets.forEach(dataset => {
        dataset.data = dataset.data.slice(-days);
    });
    window.priceTrendChart.update();
}

// Apply filters
function applyFilters() {
    const fishType = document.getElementById('fish-type-filter').value;
    const timePeriod = document.getElementById('time-period').value;
    const region = document.getElementById('region-filter').value;
    
    // In a real app, this would filter the data from the server
    console.log('Filters applied:', { fishType, timePeriod, region });
    
    // For demo purposes, we'll just show a message
    alert(`Filters applied:\nFish Type: ${fishType}\nTime Period: ${timePeriod}\nRegion: ${region}`);
}

// Populate forecast sections
function populateForecasts() {
    const shortTerm = document.getElementById('short-term-forecast');
    const longTerm = document.getElementById('long-term-forecast');
    
    shortTerm.innerHTML = '';
    longTerm.innerHTML = '';
    
    // Short-term forecasts
    marketData.shortTermForecast.forEach(item => {
        const element = document.createElement('div');
        element.className = 'forecast-item';
        element.innerHTML = `
            <span class="forecast-label">${item.label}</span>
            <span class="forecast-value ${item.trend}">${item.value}</span>
        `;
        shortTerm.appendChild(element);
    });
    
    // Long-term forecasts
    marketData.longTermForecast.forEach(item => {
        const element = document.createElement('div');
        element.className = 'forecast-item';
        element.innerHTML = `
            <span class="forecast-label">${item.label}</span>
            <span class="forecast-value ${item.trend}">${item.value}</span>
        `;
        longTerm.appendChild(element);
    });
}

// Populate recommendations
function populateRecommendations() {
    const recommendations = document.getElementById('buy-sell-recommendations');
    const alerts = document.getElementById('inventory-alerts');
    
    recommendations.innerHTML = '';
    alerts.innerHTML = '';
    
    // Buy/Sell recommendations
    marketData.recommendations.buySell.forEach(item => {
        const element = document.createElement('div');
        element.className = 'recommendation-item';
        element.innerHTML = `
            <i class="fas fa-${item.icon}"></i>
            <div class="recommendation-content">
                <strong>${item.title}</strong>
                <p>${item.description}</p>
            </div>
        `;
        recommendations.appendChild(element);
    });
    
    // Inventory alerts
    marketData.recommendations.inventory.forEach(item => {
        const element = document.createElement('div');
        element.className = `alert-item ${item.type}`;
        element.innerHTML = `
            <i class="fas fa-${item.icon}"></i>
            <div class="alert-content">
                <strong>${item.title}</strong>
                <p>${item.description}</p>
            </div>
        `;
        alerts.appendChild(element);
    });
    
    // Competitor benchmarking table
    const benchmarkTable = document.getElementById('competitor-benchmarking');
    benchmarkTable.innerHTML = `
        <table class="benchmark-table">
            <thead>
                <tr>
                    <th>Fish Type</th>
                    <th>FinCash Price</th>
                    <th>Market Price</th>
                    <th>Difference</th>
                </tr>
            </thead>
            <tbody>
                ${marketData.competitorBenchmarking.map(item => `
                    <tr>
                        <td>${item.fish}</td>
                        <td>₹${item.ourPrice.toFixed(2)}</td>
                        <td>₹${item.marketPrice.toFixed(2)}</td>
                        <td class="${item.difference >= 0 ? 'up' : 'down'}">
                            ${item.difference >= 0 ? '+' : ''}${item.difference.toFixed(2)}%
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
}

    
});

// Keep all your existing helper functions below
// (populateMarketOverview, initCharts, getChartOptions, updateCharts, etc.)
// They should remain exactly the same as in your original code